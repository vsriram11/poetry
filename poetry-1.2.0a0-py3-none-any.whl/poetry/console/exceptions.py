from cleo.exceptions import CleoSimpleException


class PoetrySimpleConsoleException(CleoSimpleException):

    pass

import sys


if __name__ == "__main__":
    from .console.application import main

    sys.exit(main())
